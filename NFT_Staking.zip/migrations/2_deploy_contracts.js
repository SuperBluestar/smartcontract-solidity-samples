const Cifi_Token = artifacts.require("Cifi_Token");
const Test_Token = artifacts.require("Test_Token");
const Santa = artifacts.require("Santa");
const SantaFactory = artifacts.require("SantaFactory");
// const NftAsset = artifacts.require("NftAsset");
// const NftFactory = artifacts.require("NftFactory");
const SantaV2 = artifacts.require("SantaV2");
const SantaFactoryV2 = artifacts.require("SantaFactoryV2");
const SantaFactory2V2 = artifacts.require("SantaFactory2V2");
const NftStaking = artifacts.require("NftStaking");
const NftStakingV2 = artifacts.require("NftStakingV2");

module.exports = async function (deployer) {
  const accounts = await web3.eth.getAccounts();
  // await deployer.deploy(Cifi_Token, { from: accounts[0], overwrite: false });
  // await deployer.deploy(Test_Token, { from: accounts[0], overwrite: false });
  // await deployer.deploy(Santa, { from: accounts[0], overwrite: false });
  // await deployer.deploy(SantaFactory, Cifi_Token.address, Santa.address, {
  //   from: accounts[0],
  //   overwrite: false,
  // });
  // await deployer.deploy(NftStaking, Cifi_Token.address, Santa.address, {
  //   from: accounts[0],
  //   overwrite: true,
  // });
  // await Santa.addMinter(SantaFactory.address);
  // await deployer.deploy(NFTReward, Cifi_Token.address, NftAsset.address, {
  //   from: accounts[0],
  //   overwrite: false,
  // });

  // await deployer.deploy(
  //   SantaV2,
  //   "Test NFT",
  //   "TESTNFT",
  //   "https://api.santafeapp.io/test-asset/",
  //   { from: accounts[0], overwrite: false }
  // );

  const vrfCoordinator = "0x8C7382F9D8f56b33781fE506E897a4F1e2d17255";
  const linkToken = "0x326C977E6efc84E512bB9C30f76E30c160eD06FB";
  const linkKeyHash =
    "0x6e75b569a01ef56d18cab6a8e71e6600d6ce853834d4a5748b720d06f878b3a4";
  const linkFee = BigInt("100000000000000");
  await deployer.deploy(
    SantaFactoryV2,
    Cifi_Token.address,
    10000,
    vrfCoordinator,
    linkToken,
    linkKeyHash,
    linkFee,
    { from: accounts[0], overwrite: true }
  );
  // await deployer.deploy(
  //   SantaFactory2V2,
  //   Cifi_Token.address,
  //   vrfCoordinator,
  //   linkToken,
  //   linkKeyHash,
  //   linkFee,
  //   { from: accounts[0], overwrite: false }
  // );
  // santaFactory2V2 = await SantaFactory2V2.deployed();
  // await santaFactory2V2.createSanta(
  //   "TestFiance2",
  //   "TESTNFT2",
  //   "https://api.santafeapp.io/test-asset/",
  //   Test_Token.address,
  //   10000
  // );
  // console.log(await santaFactory2V2.getContractNames());
  // console.log(await santaFactory2V2.getContractData("TestFiance"));
  // await SantaV2.addMinter(SantaFactoryV2.address);
  // await deployer.deploy(
  //   NftStakingV2,
  //   Cifi_Token.address,
  //   SantaV2.address,
  //   SantaFactoryV2.address,
  //   { from: accounts[0], overwrite: true }
  // );
};
